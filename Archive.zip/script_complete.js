// ===========================
// Prompt Forge V2 - Main Script
// ===========================

document.addEventListener('DOMContentLoaded', function() {
    // --- Global Variables & Constants ---
    let selectedKeywords = {}; // Stores { categoryId: [{id, value, label}, ...] }
    let currentComfyWorkflow = null; // Stores the JSON content of the selected ComfyUI workflow
    let isBatchStopped = false; // Flag for stopping continuous generation

    // DOM Element References (cached for performance)
    const domElements = {
        // Keyword & Prompt Output
        feelLuckyButton: document.getElementById('feelLuckyButton'),
        luckyQuantityOptions: document.getElementById('lucky-quantity-options'),
        generateKeywordsButton: document.getElementById('generateKeywordsButton'),
        mainMessageBox: document.getElementById('mainMessageBox'),
        generatedKeywordsTextarea: document.getElementById('generatedKeywords'),
        apiGeneratedPromptTextarea: document.getElementById('apiGeneratedPrompt'),
        // LLM Config
        llmEndpointSelect: document.getElementById('llmEndpoint'),
        customLlmEndpointContainer: document.getElementById('customLlmEndpointContainer'),
        customLlmEndpointInput: document.getElementById('customLlmEndpoint'),
        llmApiKeyInput: document.getElementById('llmApiKey'),
        clearApiKeyButton: document.getElementById('clearApiKeyButton'),
        geminiModelContainer: document.getElementById('geminiModelContainer'),
        geminiModelSelect: document.getElementById('geminiModelSelect'),
        otherModelContainer: document.getElementById('otherModelContainer'),
        llmModelNameInput: document.getElementById('llmModelName'),
        systemPromptTextarea: document.getElementById('systemPrompt'),
        configMessageBox: document.getElementById('configMessageBox'),
        generateApiPromptButton: document.getElementById('generateApiPromptButton'),
        promptFormatRadios: document.querySelectorAll('input[name="promptFormat"]'),
        // Image Gen Config
        comfyuiLocationSelector: document.getElementById('comfyui-location-selector'),
        comfyuiLanAddressInput: document.getElementById('comfyuiLanAddressInline'),
        // comfyuiCustomAddressInput: document.getElementById('comfyuiCustomAddress'), // This ID might change if you merged LAN and Custom
        comfyWorkflowSelect: document.getElementById('comfyWorkflowSelect'),
        workflowEditor: document.getElementById('workflowEditor'),
        customComfyEndpointsList: document.getElementById('custom-comfy-endpoints-list'),
        addCustomComfyEndpointBtn: document.getElementById('add-custom-comfy-endpoint-btn'),
        promptToSendRadios: document.querySelectorAll('input[name="promptToSend"]'),
        enableSuccessivePromptCheckbox: document.getElementById('enableSuccessivePrompt'),
        enableContinuousGenCheckbox: document.getElementById('enableContinuousGen'),
        continuousOptionsDiv: document.getElementById('continuousOptionsDiv'),
        continuousGenCountInput: document.getElementById('continuousGenCount'),
        continuousGenModeRadios: document.querySelectorAll('input[name="continuousGenMode"]'),
        sendPromptButton: document.getElementById('sendPromptButton'),
        stopBatchButton: document.getElementById('stopBatchButton'),
        // Keyword Selection
        keywordDetailsDisplay: document.getElementById('keyword-details-display'),
        // Results
        imageResultsGrid: document.getElementById('image-results-grid'),
        clearResultsButton: document.getElementById('clearResultsButton'),
        downloadResultsButton: document.getElementById('downloadResultsButton'),
        // Image Modal
        imageModalOverlay: document.getElementById('imageModalOverlay'),
        modalImage: document.getElementById('modalImage'),
        modalCloseBtn: document.getElementById('modalCloseBtn'),
        // Collapsible sections
        collapseToggleButtons: document.querySelectorAll('.collapse-toggle-button')
    };

    // --- Initialization ---
    function initializeApp() {
        console.log("Initializing Prompt Forge V2...");
        if (typeof dropdownData === 'undefined' || typeof comfyWorkflows === 'undefined' || typeof storedApiKeys === 'undefined') {
            showMessage('error', "Critical data (dropdownData, comfyWorkflows, or storedApiKeys) not loaded. Check data.js.");
            return;
        }
        populateDropdowns();
        populateComfyWorkflows();
        loadLlmApiKey();
        loadCustomComfyEndpoints();
        setupEventListeners();
        setDefaultPromptFormat();
        setDefaultPromptToSend();
        updateModelVisibility(); // Initial check for LLM model fields
        console.log("Prompt Forge V2 Initialized.");
    }

    // --- Keyword Selection & Display ---
    function populateDropdowns() {
        for (const categoryId in dropdownData) {
            const container = document.getElementById(categoryId);
            if (!container) {
                console.warn(`Container not found for category ID: ${categoryId}`);
                continue;
            }
            const select = document.createElement('select');
            select.id = `${categoryId}-select`;
            select.className = 'keyword-select';
            select.multiple = true;

            const placeholderOption = document.createElement('option');
            placeholderOption.disabled = true;
            placeholderOption.textContent = 'Select options...';
            select.appendChild(placeholderOption);

            dropdownData[categoryId].forEach(item => {
                const option = document.createElement('option');
                option.value = item.value;
                option.textContent = item.label;
                option.dataset.id = item.id;
                select.appendChild(option);
            });
            select.addEventListener('change', () => onKeywordSelectionChange(categoryId, select));
            container.innerHTML = ''; // Clear potential old content
            container.appendChild(select);
        }
    }

    function onKeywordSelectionChange(categoryId, selectElement) {
        const currentSelections = Array.from(selectElement.selectedOptions)
            .filter(opt => !opt.disabled)
            .map(opt => ({ id: opt.dataset.id, value: opt.value, label: opt.textContent }));

        if (currentSelections.length > 0) {
            selectedKeywords[categoryId] = currentSelections;
        } else {
            delete selectedKeywords[categoryId];
        }
        updateKeywordDisplay();
        generateKeywordsSummary(); // Live update
    }

    function updateKeywordDisplay() {
        if (!domElements.keywordDetailsDisplay) return;
        if (Object.keys(selectedKeywords).length === 0) {
            domElements.keywordDetailsDisplay.innerHTML = '<p class="no-selections">No keywords selected. Choose from categories above.</p>';
            return;
        }
        let html = '';
        for (const categoryId in selectedKeywords) {
            const items = selectedKeywords[categoryId];
            const containerElement = document.getElementById(categoryId);
            let categoryName = categoryId.replace(/([A-Z])/g, ' $1').trim(); // Default
            if (containerElement && containerElement.previousElementSibling && containerElement.previousElementSibling.classList.contains('dropdown-label')) {
                categoryName = containerElement.previousElementSibling.textContent.replace(':', '').trim();
            }

            html += `<div class="keyword-category-display"><h4>${categoryName}</h4><div class="selected-keywords">`;
            items.forEach(item => {
                html += `<span class="keyword-chip" data-category="${categoryId}" data-id="${item.id}">
                           ${item.label}
                           <button type="button" class="remove-keyword" title="Remove keyword">&times;</button>
                         </span>`;
            });
            html += `</div></div>`;
        }
        domElements.keywordDetailsDisplay.innerHTML = html;
        domElements.keywordDetailsDisplay.querySelectorAll('.remove-keyword').forEach(button => {
            button.addEventListener('click', onRemoveKeywordClick);
        });
    }

    function onRemoveKeywordClick(event) {
        const chip = event.target.closest('.keyword-chip');
        const categoryId = chip.dataset.category;
        const itemId = chip.dataset.id;
        
        const selectElement = document.getElementById(`${categoryId}-select`);
        const optionToDeselect = Array.from(selectElement.options).find(opt => opt.dataset.id === itemId);
        if (optionToDeselect) optionToDeselect.selected = false;
        
        onKeywordSelectionChange(categoryId, selectElement); // Re-trigger update
    }
    
    function generateKeywordsSummary() {
        let allKeywords = [];
        for (const categoryId in selectedKeywords) {
            selectedKeywords[categoryId].forEach(item => allKeywords.push(item.value));
        }
        shuffleArray(allKeywords); // Add some randomness
        domElements.generatedKeywordsTextarea.value = allKeywords.join(', ');
    }

    function onFeelLuckyClick() {
        clearAllSelections();
        const quantityOption = domElements.luckyQuantityOptions.querySelector('input[name="luckyQuantity"]:checked').value;
        const [min, max] = quantityOption.split('-').map(Number);
        const numToSelect = Math.floor(Math.random() * (max - min + 1)) + min;

        const allOptions = [];
        for (const categoryId in dropdownData) {
            const selectElement = document.getElementById(`${categoryId}-select`);
            if (selectElement) {
                dropdownData[categoryId].forEach(item => {
                    if (item.value) { // Ensure item has a value
                         allOptions.push({ categoryId, item, selectElement });
                    }
                });
            }
        }
        shuffleArray(allOptions);

        let count = 0;
        const categoryCounts = {};
        for (const opt of allOptions) {
            if (count >= numToSelect) break;
            // Limit selections per category for better distribution (optional)
            categoryCounts[opt.categoryId] = (categoryCounts[opt.categoryId] || 0);
            if (categoryCounts[opt.categoryId] < 3) { // Max 3 from one category
                 const optionElement = Array.from(opt.selectElement.options).find(o => o.dataset.id === opt.item.id);
                 if (optionElement && !optionElement.selected) {
                    optionElement.selected = true;
                    count++;
                    categoryCounts[opt.categoryId]++;
                 }
            }
        }
        // Update all affected select elements
        for (const categoryId in dropdownData) {
            const selectElement = document.getElementById(`${categoryId}-select`);
            if (selectElement) onKeywordSelectionChange(categoryId, selectElement);
        }
    }

    function clearAllSelections() {
        for (const categoryId in dropdownData) {
            const selectElement = document.getElementById(`${categoryId}-select`);
            if (selectElement) {
                Array.from(selectElement.options).forEach(opt => opt.selected = false);
                onKeywordSelectionChange(categoryId, selectElement); // Update each category
            }
        }
        // selectedKeywords should be empty now due to onKeywordSelectionChange calls
        updateKeywordDisplay(); // Ensure display is cleared
        generateKeywordsSummary(); // Ensure summary is cleared
    }

    // --- LLM & API Configuration ---
    function onLlmEndpointChange() {
        updateModelVisibility();
    }

    function updateModelVisibility() {
        const selectedEndpoint = domElements.llmEndpointSelect.value;
        domElements.customLlmEndpointContainer.style.display = (selectedEndpoint === 'custom_llm') ? 'block' : 'none';
        domElements.geminiModelContainer.style.display = (selectedEndpoint.includes('generativelanguage')) ? 'block' : 'none';
        domElements.otherModelContainer.style.display = (selectedEndpoint !== 'custom_llm' && !selectedEndpoint.includes('generativelanguage')) ? 'block' : 'none';
        
        if (selectedEndpoint.includes('generativelanguage')) populateGeminiModels();
    }
    
    function populateGeminiModels() {
        const models = storedApiKeys.geminiModels || ["gemini-1.5-flash-latest", "gemini-1.5-pro-latest"];
        domElements.geminiModelSelect.innerHTML = models.map(m => `<option value="${m}">${m}</option>`).join('');
        // Select a default, e.g., the first one
        if (models.length > 0) domElements.geminiModelSelect.value = models[0];
    }

    function loadLlmApiKey() {
        const savedKey = localStorage.getItem('llmApiKey');
        if (savedKey) domElements.llmApiKeyInput.value = savedKey;
    }

    function saveLlmApiKey() {
        localStorage.setItem('llmApiKey', domElements.llmApiKeyInput.value);
         showMessage('info', 'API Key saved to local browser storage.', domElements.configMessageBox);
    }

    function onClearApiKeyClick() {
        domElements.llmApiKeyInput.value = '';
        localStorage.removeItem('llmApiKey');
        showMessage('info', 'API Key cleared.', domElements.configMessageBox);
    }
    
    function setDefaultPromptFormat() {
        const defaultFormat = 'Flux'; // Default to Flux
        const radioToCheck = Array.from(domElements.promptFormatRadios).find(r => r.value === defaultFormat);
        if (radioToCheck) {
            radioToCheck.checked = true;
            updateSystemPrompt(defaultFormat);
        }
    }

    function onPromptFormatChange(event) {
        updateSystemPrompt(event.target.value);
    }

    function updateSystemPrompt(format) {
        let promptText = '';
        switch (format) {
            case 'auto':
                promptText = 'Create a detailed, vivid image prompt based on the keywords provided. Balance descriptive language with specific keywords. Focus on visual elements, composition, lighting, and style. The prompt should be creative and evocative, suitable for image generation models.';
                break;
            case 'StableDiffusion': // Keywords
                promptText = 'Convert these keywords into a concise, comma-separated prompt optimized for Stable Diffusion. Focus on key visual elements, style descriptors, and composition. Avoid natural language sentences. Use weight indicators like (word) or (word:1.2) for important elements. Keep the prompt under 70 words, emphasizing visual quality descriptors.';
                break;
            case 'SDXL': // Structured
                promptText = 'Create a structured, detailed prompt for SDXL based on these keywords. Organize into clear visual elements with logical flow. Include subject, setting, lighting, style, and quality descriptors. Use natural phrases rather than just comma-separated keywords. Emphasize composition and mood. The prompt should be comprehensive but focused, highlighting the most important visual elements.';
                break;
            case 'Flux': // Sentences
                promptText = 'Transform these keywords into a balanced, descriptive prompt for Flux image generation. Combine natural language with specific style keywords. Describe the scene, subject, mood, lighting, and artistic style clearly. Use a mix of sentences and key descriptors. Focus on creating a cohesive visual concept that captures the essence of the keywords while providing clear direction for the image generation.';
                break;
            default:
                promptText = 'Provide a general, well-balanced prompt based on the keywords.';
        }
        domElements.systemPromptTextarea.value = promptText;
    }

    async function onGenerateApiPromptClick() {
        const keywords = domElements.generatedKeywordsTextarea.value.trim();
        if (!keywords) {
            showMessage('warning', 'Please generate or select keywords first.', domElements.configMessageBox);
            return;
        }
        showMessage('info', 'Generating API prompt...', domElements.configMessageBox);
        try {
            const refinedPrompt = await callLLM(keywords);
            domElements.apiGeneratedPromptTextarea.value = refinedPrompt;
            showMessage('success', 'API prompt generated successfully!', domElements.configMessageBox);
        } catch (error) {
            showMessage('error', `API Prompt Generation Error: ${error.message}`, domElements.configMessageBox);
        }
    }
    
    async function callLLM(promptContent) {
        const endpoint = domElements.llmEndpointSelect.value;
        const apiKey = domElements.llmApiKeyInput.value || (endpoint.includes('generativelanguage') ? storedApiKeys.gemini : '');
        const systemPrompt = domElements.systemPromptTextarea.value;
        let modelName = '';
        let requestUrl = '';
        let requestBody = {};
        let headers = { 'Content-Type': 'application/json' };

        if (endpoint.includes('generativelanguage')) { // Gemini
            modelName = domElements.geminiModelSelect.value;
            if (!apiKey) throw new Error("Gemini API Key is missing.");
            requestUrl = `${endpoint}/models/${modelName}:generateContent?key=${apiKey}`;
            requestBody = {
                contents: [{ role: "user", parts: [{ text: promptContent }] }],
                ...(systemPrompt && { systemInstruction: { role: "system", parts: [{ text: systemPrompt }] } }),
                generationConfig: { temperature: 0.7, maxOutputTokens: 800 }
            };
        } else if (endpoint === 'custom_llm' || endpoint.includes('localhost')) { // OpenAI compatible (LM Studio, Ollama, Custom)
            modelName = domElements.llmModelNameInput.value.trim();
            requestUrl = (endpoint === 'custom_llm') ? domElements.customLlmEndpointInput.value.trim() : endpoint;
            if (!requestUrl) throw new Error("LLM Endpoint URL is missing.");
            // Ensure path is correctly formed for OpenAI-compatible endpoints
            if (!requestUrl.endsWith('/v1/chat/completions') && !requestUrl.endsWith('/chat/completions')) {
                 // Common paths, if not already part of the user-provided URL for custom
                if (requestUrl.includes('localhost:1234')) requestUrl = `${requestUrl.replace(/\/v1$/, '')}/v1/chat/completions`; // Ensure LM Studio has /v1
                else if (requestUrl.includes('localhost:11434') && !requestUrl.endsWith('/api/chat')) requestUrl = `${requestUrl.replace(/\/v1$/, '')}/api/chat`; // Ollama specific path
                else if (endpoint === 'custom_llm' && !requestUrl.endsWith('/v1/chat/completions')) requestUrl = `${requestUrl}/v1/chat/completions`; // Generic custom
            }


            requestBody = {
                model: modelName || "default-model", // Model name might be optional for some local servers
                messages: [
                    ...(systemPrompt ? [{ role: "system", content: systemPrompt }] : []),
                    { role: "user", content: promptContent }
                ],
                temperature: 0.7,
                max_tokens: 800 // OpenAI uses max_tokens
            };
            if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
        } else {
            throw new Error("Unsupported LLM endpoint selected.");
        }

        const response = await fetch(requestUrl, { method: 'POST', headers: headers, body: JSON.stringify(requestBody) });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: response.statusText }));
            throw new Error(`API Error (${response.status}): ${errorData.error?.message || errorData.message || 'Unknown error'}`);
        }
        const data = await response.json();
        
        // Handle different response structures
        if (endpoint.includes('generativelanguage')) { // Gemini
            return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "";
        } else if (requestUrl.endsWith('/api/chat')) { // Ollama /api/chat
             return data.message?.content?.trim() || "";
        }
        else { // OpenAI compatible
            return data.choices?.[0]?.message?.content?.trim() || "";
        }
    }

    // --- Image Generation & ComfyUI ---
    function populateComfyWorkflows() {
        domElements.comfyWorkflowSelect.innerHTML = Object.keys(comfyWorkflows)
            .map(key => `<option value="${key}">${comfyWorkflows[key].name}</option>`).join('');
        // Load default workflow content
        if (Object.keys(comfyWorkflows).length > 0) {
            domElements.comfyWorkflowSelect.value = "GGUF-COMFY"; // Default to GGUF-COMFY
            onComfyWorkflowChange();
        }
    }

    async function onComfyWorkflowChange() {
        const selectedKey = domElements.comfyWorkflowSelect.value;
        if (!selectedKey) return;
        try {
            const response = await fetch(comfyWorkflows[selectedKey].path);
            if (!response.ok) throw new Error(`HTTP error ${response.status}`);
            currentComfyWorkflow = await response.json(); // Store the JSON object
            domElements.workflowEditor.value = JSON.stringify(currentComfyWorkflow, null, 2);
        } catch (error) {
            console.error('Error loading workflow:', error);
            domElements.workflowEditor.value = `Error loading workflow: ${error.message}`;
            currentComfyWorkflow = null;
        }
    }
    
    function getComfyUiServerAddress() {
        const selectedLocation = domElements.comfyuiLocationSelector.querySelector('input[name="comfyuiLocation"]:checked').value;
        if (selectedLocation === 'local') return "http://127.0.0.1:8188";
        if (selectedLocation === 'lan') return domElements.comfyuiLanAddressInput.value.trim();
        // Handle custom endpoints from localStorage if that feature is re-added
        const selectedCustom = Array.from(domElements.customComfyEndpointsList.querySelectorAll('input[name="customComfyEndpoint"]:checked'));
        if (selectedCustom.length > 0) return selectedCustom[0].value;
        return null;
    }

    async function onSendPromptToComfyUIClick() {
        const serverAddress = getComfyUiServerAddress();
        if (!serverAddress) {
            showMessage('error', "ComfyUI server address not configured.", domElements.mainMessageBox);
            return;
        }
        if (!currentComfyWorkflow) {
            showMessage('error', "No ComfyUI workflow loaded.", domElements.mainMessageBox);
            return;
        }

        const promptType = domElements.promptToSendRadios.length > 0 ? domElements.promptToSendRadios[0].form.elements.promptToSend.value : 'api';
        const promptText = (promptType === 'keywords' ? domElements.generatedKeywordsTextarea.value : domElements.apiGeneratedPromptTextarea.value).trim();
        if (!promptText) {
            showMessage('warning', "Prompt is empty.", domElements.mainMessageBox);
            return;
        }

        isBatchStopped = false; // Reset stop flag
        domElements.sendPromptButton.disabled = true;
        domElements.stopBatchButton.style.display = domElements.enableContinuousGenCheckbox.checked ? 'inline-block' : 'none';

        if (domElements.enableContinuousGenCheckbox.checked) {
            const count = parseInt(domElements.continuousGenCountInput.value, 10);
            for (let i = 0; i < count; i++) {
                if (isBatchStopped) {
                    showMessage('info', `Batch generation stopped at ${i} images.`, domElements.mainMessageBox);
                    break;
                }
                showMessage('info', `Generating image ${i + 1} of ${count}...`, domElements.mainMessageBox);
                await generateSingleImage(serverAddress, promptText, i + 1, count);
                
                // Handle continuous mode variations
                if (i < count - 1 && domElements.continuousGenModeRadios.length > 0) {
                    const mode = domElements.continuousGenModeRadios[0].form.elements.continuousGenMode.value;
                    if (mode === 'new_lucky_api') {
                        onFeelLuckyClick(); // Generates new keywords and summary
                        await onGenerateApiPromptClick(); // Generates new API prompt
                        // Update promptText for the next iteration:
                        // promptText = (promptType === 'keywords' ? domElements.generatedKeywordsTextarea.value : domElements.apiGeneratedPromptTextarea.value).trim();
                        // Simplified: always use API prompt if available and successive mode is not about keywords
                        promptText = domElements.apiGeneratedPromptTextarea.value.trim() || domElements.generatedKeywordsTextarea.value.trim();

                    } else if (mode === 'keep_keywords_new_api') {
                        await onGenerateApiPromptClick();
                        promptText = domElements.apiGeneratedPromptTextarea.value.trim();
                    }
                }
            }
            if (!isBatchStopped) showMessage('success', `Batch of ${count} images complete!`, domElements.mainMessageBox);
        } else {
            await generateSingleImage(serverAddress, promptText, 1, 1);
        }

        domElements.sendPromptButton.disabled = false;
        domElements.stopBatchButton.style.display = 'none';
    }

    async function generateSingleImage(serverAddress, currentPromptText, batchNum, totalBatch) {
        const workflow = JSON.parse(JSON.stringify(currentComfyWorkflow)); // Deep clone
        let modifiedPromptText = currentPromptText;

        // Experimental: Second round with keywords if API prompt was initially used
        if (domElements.enableSuccessivePromptCheckbox.checked && domElements.apiGeneratedPromptTextarea.value === currentPromptText && domElements.generatedKeywordsTextarea.value) {
            // This logic might need refinement on how it determines "second round" in a batch
            // For now, let's assume if this checkbox is on, it tries to append/use keywords
            // This is a placeholder for a more robust successive refinement strategy
            console.log("Attempting successive prompt with keywords.");
            modifiedPromptText += ", " + domElements.generatedKeywordsTextarea.value.trim(); // Simple append
        }

        // Find prompt nodes and update them (example logic, needs to match your workflow structure)
        // This part is highly dependent on the structure of your ComfyUI workflow JSON
        let promptInjected = false;
        for (const nodeId in workflow) {
            const node = workflow[nodeId];
            if (node.class_type === "CLIPTextEncode" || node.class_type === "KSamplerPrompt") { // Common prompt nodes
                if (node.inputs && typeof node.inputs.text === 'string') {
                    node.inputs.text = modifiedPromptText; // Positive prompt
                    promptInjected = true;
                }
                 if (node.inputs && typeof node.inputs.positive === 'string') { // Another common way
                    node.inputs.positive = modifiedPromptText;
                    promptInjected = true;
                }
                 // Handle negative prompts if your workflow uses them
                if (node.inputs && typeof node.inputs.negative === 'string') {
                     // You might want a dedicated negative prompt textarea or use a default
                    node.inputs.negative = "low quality, worst quality, bad anatomy, bad hands, text, error";
                }
            }
            // FLUX specific node
            if (node.class_type === "CLIPTextEncodeFlux") {
                 if (node.inputs && typeof node.inputs.text === 'string') {
                    node.inputs.text = modifiedPromptText;
                    promptInjected = true;
                }
            }
             // Handle seed randomization if node exists
            if (node.inputs && node.inputs.seed !== undefined) {
                node.inputs.seed = Math.floor(Math.random() * 1_000_000_000_000_000); // Random seed
            }
            if (node.inputs && node.inputs.noise_seed !== undefined) {
                 node.inputs.noise_seed = Math.floor(Math.random() * 1_000_000_000_000_000);
            }
        }

        if (!promptInjected) {
            console.warn("Could not find a standard prompt input in the workflow. Prompt not injected.");
            // Optionally show a message to the user
        }
        
        const resultItemId = `result-${Date.now()}-${batchNum}`;
        addProvisionalResultItem(resultItemId, `Batch ${batchNum}/${totalBatch}: Queuing...`);

        try {
            const response = await fetch(`${serverAddress}/prompt`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: workflow })
            });
            if (!response.ok) throw new Error(`Queueing error: ${response.statusText}`);
            const data = await response.json();
            if (data.error) throw new Error(`Workflow error: ${JSON.stringify(data.error)}`);
            
            updateProvisionalResultItem(resultItemId, `Batch ${batchNum}/${totalBatch}: Processing (Prompt ID: ${data.prompt_id}). Waiting for image...`);
            // Start polling for results (simplified, no WebSocket for this example)
            await pollForResult(serverAddress, data.prompt_id, resultItemId, modifiedPromptText);

        } catch (error) {
            console.error('Error sending prompt to ComfyUI:', error);
            updateProvisionalResultItem(resultItemId, `Error: ${error.message}`, true);
            showMessage('error', `ComfyUI Error: ${error.message}`, domElements.mainMessageBox);
        }
    }

    async function pollForResult(serverAddress, promptId, resultItemId, promptText) {
        const historyUrl = `${serverAddress}/history/${promptId}`;
        const maxAttempts = 120; // Poll for up to 2 minutes (120 * 1s)
        let attempts = 0;

        while (attempts < maxAttempts && !isBatchStopped) {
            await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
            try {
                const response = await fetch(historyUrl);
                if (!response.ok) { // Still processing or server error
                    updateProvisionalResultItem(resultItemId, `Polling (${attempts}/${maxAttempts})... Server status: ${response.status}`);
                    attempts++;
                    continue;
                }
                const historyData = await response.json();
                const promptHistory = historyData[promptId];

                if (promptHistory && promptHistory.outputs) {
                    const imageOutputNodeId = Object.keys(promptHistory.outputs).find(nodeId =>
                        promptHistory.outputs[nodeId].images && promptHistory.outputs[nodeId].images.length > 0
                    );
                    if (imageOutputNodeId) {
                        const imageInfo = promptHistory.outputs[imageOutputNodeId].images[0];
                        const imageUrl = `${serverAddress}/view?filename=${encodeURIComponent(imageInfo.filename)}&subfolder=${encodeURIComponent(imageInfo.subfolder)}&type=${imageInfo.type}`;
                        displayImageResult(resultItemId, imageUrl, promptText, promptHistory.outputs); // Pass all outputs for metadata
                        return; // Success
                    }
                }
                updateProvisionalResultItem(resultItemId, `Polling (${attempts}/${maxAttempts})... Waiting for output.`);
            } catch (error) {
                console.error("Polling error:", error);
                updateProvisionalResultItem(resultItemId, `Polling error: ${error.message}. Retrying...`);
            }
            attempts++;
        }
        if (!isBatchStopped) {
            updateProvisionalResultItem(resultItemId, "Timeout or error waiting for image.", true);
        } else {
            updateProvisionalResultItem(resultItemId, "Batch stopped by user.", true);
        }
    }

    function addProvisionalResultItem(id, statusText) {
        if (domElements.imageResultsGrid.querySelector('.results-placeholder')) {
            domElements.imageResultsGrid.innerHTML = ''; // Clear placeholder
        }
        const item = document.createElement('div');
        item.className = 'image-result-item';
        item.id = id;
        item.innerHTML = `
            <h4>Image ${id.split('-').pop()}</h4>
            <img src="placeholder-loading.png" alt="Generating..." class="result-image placeholder">
            <p class="status-message loading">${statusText}</p>
            <div class="image-metadata"></div>
        `;
        domElements.imageResultsGrid.prepend(item); // Add new items at the top
    }

    function updateProvisionalResultItem(id, statusText, isError = false) {
        const item = document.getElementById(id);
        if (item) {
            const statusEl = item.querySelector('.status-message');
            statusEl.textContent = statusText;
            statusEl.className = `status-message ${isError ? 'error' : 'loading'}`;
        }
    }
    
    function displayImageResult(itemId, imageUrl, promptText, allOutputs) {
        const item = document.getElementById(itemId);
        if (!item) return;

        const img = item.querySelector('img');
        img.src = imageUrl;
        img.alt = promptText.substring(0, 100); // Alt text from prompt
        img.classList.remove('placeholder');
        img.onload = () => item.querySelector('.status-message').remove(); // Remove status on load
        img.onerror = () => {
            item.querySelector('.status-message').textContent = 'Error loading image.';
            item.querySelector('.status-message').classList.add('error');
        };
        img.addEventListener('click', () => showImageModal(imageUrl)); // Open in modal

        // Populate metadata (example)
        const metadataDiv = item.querySelector('.image-metadata');
        let metadataHTML = '';
        try {
            // Try to find seed from common KSampler nodes
            const ksamplerNodeId = Object.keys(allOutputs).find(id => allOutputs[id].widgets_values && allOutputs[id].widgets_values.find(val => typeof val === 'number' && id.toLowerCase().includes("sampler")));
            if (ksamplerNodeId) {
                 const seedWidget = allOutputs[ksamplerNodeId].widgets_values.find(val => typeof val === 'number' && (allOutputs[ksamplerNodeId].inputs.seed !==undefined || allOutputs[ksamplerNodeId].inputs.noise_seed !==undefined));
                 if(seedWidget !== undefined) metadataHTML += `<span><strong>Seed:</strong> ${seedWidget}</span>`;
            }
            metadataHTML += `<span><strong>Prompt:</strong> ${promptText.substring(0, 100)}...</span>`;
             // Add more metadata as needed by inspecting 'allOutputs'
        } catch(e) { console.error("Error extracting metadata:", e); }
        metadataDiv.innerHTML = metadataHTML;
    }

    function onStopBatchClick() {
        isBatchStopped = true;
        showMessage('warning', "Batch generation stopping...", domElements.mainMessageBox);
        domElements.stopBatchButton.disabled = true; // Prevent multiple clicks
    }
    
    function onClearResultsClick() {
        domElements.imageResultsGrid.innerHTML = `
            <div class="results-placeholder">
                <p>Generated images will appear here.</p>
                <p class="results-tip">Tip: Try the "Feeling Lucky" button for random keywords!</p>
            </div>`;
        showMessage('info', "Results cleared.", domElements.mainMessageBox);
    }

    // --- Custom ComfyUI Endpoint Management ---
    function loadCustomComfyEndpoints() {
        const endpoints = JSON.parse(localStorage.getItem('customComfyEndpoints') || '[]');
        renderCustomComfyEndpoints(endpoints);
        // Add an event listener to the container for delegated events
        domElements.customComfyEndpointsList.addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-custom-comfy-endpoint-btn')) {
                const urlToRemove = event.target.dataset.url;
                removeCustomComfyEndpoint(urlToRemove);
            }
        });
    }

    function renderCustomComfyEndpoints(endpoints) {
        domElements.customComfyEndpointsList.innerHTML = endpoints.map((ep, index) => `
            <div class="custom-endpoint-item">
                <input type="radio" name="customComfyEndpoint" value="${ep.url}" id="custom-comfy-${index}" ${index === 0 ? '' : ''}> <!-- Select first by default if needed -->
                <label for="custom-comfy-${index}" class="small-label">${ep.name} (${ep.url})</label>
                <button type="button" class="remove-custom-comfy-endpoint-btn" data-url="${ep.url}" title="Remove Endpoint">&times;</button>
            </div>
        `).join('');
         // Automatically select the "On this Machine" or "LAN" if no custom ones are selected or available
        if (endpoints.length === 0 || !endpoints.some((ep, index) => document.getElementById(`custom-comfy-${index}`)?.checked)) {
            const localRadio = document.getElementById('comfy-location-local');
            if (localRadio) localRadio.checked = true;
        }
    }

    function onAddCustomComfyEndpointClick() {
        const name = prompt("Enter a name for this ComfyUI endpoint (e.g., 'My Laptop'):");
        if (!name) return;
        const url = prompt("Enter the ComfyUI URL (e.g., http://192.168.1.100:8188):");
        if (!url) return;

        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            showMessage('error', 'Invalid URL. Must start with http:// or https://', domElements.mainMessageBox);
            return;
        }

        const endpoints = JSON.parse(localStorage.getItem('customComfyEndpoints') || '[]');
        if (endpoints.some(ep => ep.url === url)) {
            showMessage('warning', 'This URL is already saved.', domElements.mainMessageBox);
            return;
        }
        endpoints.push({ name, url });
        localStorage.setItem('customComfyEndpoints', JSON.stringify(endpoints));
        renderCustomComfyEndpoints(endpoints);
         // Auto-select the newly added endpoint's radio button
        const newEndpointRadio = domElements.customComfyEndpointsList.querySelector(`input[value="${url}"]`);
        if (newEndpointRadio) {
            newEndpointRadio.checked = true;
             // Uncheck local and LAN
            document.getElementById('comfy-location-local').checked = false;
            const lanRadio = document.getElementById('comfy-location-lan');
            if(lanRadio) lanRadio.checked = false;
        }
    }
    
    function removeCustomComfyEndpoint(urlToRemove) {
        let endpoints = JSON.parse(localStorage.getItem('customComfyEndpoints') || '[]');
        endpoints = endpoints.filter(ep => ep.url !== urlToRemove);
        localStorage.setItem('customComfyEndpoints', JSON.stringify(endpoints));
        renderCustomComfyEndpoints(endpoints);
    }


    // --- Modal & UI Helpers ---
    function showImageModal(imageUrl) {
        if (domElements.imageModalOverlay && domElements.modalImage) {
            domElements.modalImage.src = imageUrl;
            domElements.imageModalOverlay.classList.add('visible');
        }
    }

    function closeImageModal() {
        if (domElements.imageModalOverlay) {
            domElements.imageModalOverlay.classList.remove('visible');
        }
    }
    
    function showMessage(type, message, messageBoxElement = domElements.mainMessageBox) {
        if (!messageBoxElement) {
            console.error("Message box element not found for message:", message);
            return;
        }
        messageBoxElement.className = `message-box message-${type}`;
        messageBoxElement.textContent = message;
        messageBoxElement.style.display = 'block';
        if (type === 'success' || type === 'info') {
            setTimeout(() => { messageBoxElement.style.display = 'none'; }, 5000);
        }
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text)
            .then(() => showMessage('success', 'Copied to clipboard!'))
            .catch(err => showMessage('error', `Failed to copy: ${err}`));
    }
    
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
    
    function setDefaultPromptToSend() {
        const apiRadio = document.getElementById('send-api-prompt');
        if (apiRadio) apiRadio.checked = true;
    }

    // --- Event Listeners Setup ---
    function setupEventListeners() {
        domElements.feelLuckyButton?.addEventListener('click', onFeelLuckyClick);
        domElements.generateKeywordsButton?.addEventListener('click', generateKeywordsSummary);

        domElements.llmEndpointSelect?.addEventListener('change', onLlmEndpointChange);
        domElements.llmApiKeyInput?.addEventListener('change', saveLlmApiKey); // Save on change
        domElements.clearApiKeyButton?.addEventListener('click', onClearApiKeyClick);
        domElements.generateApiPromptButton?.addEventListener('click', onGenerateApiPromptClick);
        domElements.promptFormatRadios.forEach(radio => radio.addEventListener('change', onPromptFormatChange));

        domElements.comfyWorkflowSelect?.addEventListener('change', onComfyWorkflowChange);
        domElements.addCustomComfyEndpointBtn?.addEventListener('click', onAddCustomComfyEndpointClick);
        domElements.sendPromptButton?.addEventListener('click', onSendPromptToComfyUIClick);
        domElements.stopBatchButton?.addEventListener('click', onStopBatchClick);
        domElements.enableContinuousGenCheckbox?.addEventListener('change', (e) => {
            domElements.continuousOptionsDiv.style.display = e.target.checked ? 'block' : 'none';
        });

        domElements.clearResultsButton?.addEventListener('click', onClearResultsClick);
        // Note: Download results functionality is not implemented in this script.

        domElements.modalCloseBtn?.addEventListener('click', closeImageModal);
        domElements.imageModalOverlay?.addEventListener('click', (e) => {
            if (e.target === domElements.imageModalOverlay) closeImageModal();
        });

        document.querySelectorAll('.copy-button').forEach(button => {
            button.addEventListener('click', () => {
                const targetId = button.dataset.target;
                const targetElement = document.getElementById(targetId);
                if (targetElement) copyToClipboard(targetElement.value);
            });
        });

        domElements.collapseToggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                const contentId = button.getAttribute('aria-controls');
                const contentElement = document.getElementById(contentId);
                const isExpanded = button.getAttribute('aria-expanded') === 'true';
                contentElement.hidden = isExpanded;
                button.setAttribute('aria-expanded', String(!isExpanded));
                button.querySelector('.collapse-icon').classList.toggle('fa-chevron-down', !isExpanded);
                button.querySelector('.collapse-icon').classList.toggle('fa-chevron-up', isExpanded);
            });
             // Initialize icon state based on aria-expanded
            const isInitiallyExpanded = button.getAttribute('aria-expanded') === 'true';
            button.querySelector('.collapse-icon').classList.toggle('fa-chevron-down', !isInitiallyExpanded);
            button.querySelector('.collapse-icon').classList.toggle('fa-chevron-up', isInitiallyExpanded);

        });
    }

    // --- Start the Application ---
    initializeApp();
});
